<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'bv-golf');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', 'root');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         ')%.RXZCTnLopNC|vT-H&3<_D oRm>B# (We{:6vBEG9PGSbXSCUHMBcEGdcdH$ri');
define('SECURE_AUTH_KEY',  '@bA*k6jMqT%CeA{}[AVg)t&5f>6w!A =9H0mf)7G#>vDYAO+9xpmVW%Ju7|DzQy;');
define('LOGGED_IN_KEY',    'F.2Tsb(5^o8<4,9BzD.IMgJ|-%r|>PxNCKbkgDT1rXBxgw8nqgBq.YEINFG*E^X=');
define('NONCE_KEY',        'DUHLO]uY!v#>t/K+a(xqOrGL[12A-?xX@u1rE}O7z?.%C>$9EV:m|Z:02`jG$R,h');
define('AUTH_SALT',        '`3+i_Ti|p@6ai#vdz!uVgvoO`NMwCrc2sQ4LFucjUG+#.Z9uuIP$tn==jRLn^z@y');
define('SECURE_AUTH_SALT', '(<M2#,hvz$YK&&/+D=%Up0%5?^*1wK=6o4VD+,PuW]p-bw2NS*hTd^)(PM[O24Xu');
define('LOGGED_IN_SALT',   '[WeS ?cxadV~GB@:S_u.*Bk>#@/2:nNh^@_}{[J&R)H^1tko?(l$4(96hFDLmer9');
define('NONCE_SALT',       '<m#5p(O@}3Qqf{K]St},Wb/O2gPBssIQJ6[Ri*bF}/0ZG9ZSn}HJ9HH=8zj$`NS:');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'bv_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
